import customtkinter as ctk
import tkinter as tk
from tkinter import messagebox

ctk.set_appearance_mode("dark")

GOLD = "#d4af37"
DARK_GOLD = "#b38f24"
DARK_BG = "#1a1a1a"
LIGHT_TEXT = "#f0f0f0"

class EgyptInABoxApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("Egypt in a Box - Phygital Experience")
        self.geometry("900x600")
        self.configure(fg_color=DARK_BG)

        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)

        self.sidebar_frame = ctk.CTkFrame(self, width=200, corner_radius=0, fg_color="#111111")
        self.sidebar_frame.grid(row=0, column=0, sticky="nsew")
        self.sidebar_frame.grid_rowconfigure(4, weight=1)

        self.logo_label = ctk.CTkLabel(self.sidebar_frame, text="Egypt in a Box\n🇪🇬 🏺", font=ctk.CTkFont(size=24, weight="bold", family="Helvetica"), text_color=GOLD)
        self.logo_label.grid(row=0, column=0, padx=20, pady=(20, 30))

        self.home_btn = ctk.CTkButton(self.sidebar_frame, text="Home", command=self.show_home_frame, fg_color="transparent", text_color=LIGHT_TEXT, hover_color="#333333", anchor="w")
        self.home_btn.grid(row=1, column=0, padx=20, pady=10, sticky="ew")

        self.explorer_btn = ctk.CTkButton(self.sidebar_frame, text="Box Explorer", command=self.show_explorer_frame, fg_color="transparent", text_color=LIGHT_TEXT, hover_color="#333333", anchor="w")
        self.explorer_btn.grid(row=2, column=0, padx=20, pady=10, sticky="ew")

        self.quiz_btn = ctk.CTkButton(self.sidebar_frame, text="History Quiz", command=self.show_quiz_frame, fg_color="transparent", text_color=LIGHT_TEXT, hover_color="#333333", anchor="w")
        self.quiz_btn.grid(row=3, column=0, padx=20, pady=10, sticky="ew")

        self.main_frame = ctk.CTkFrame(self, corner_radius=0, fg_color=DARK_BG)
        self.main_frame.grid(row=0, column=1, sticky="nsew", padx=20, pady=20)
        self.main_frame.grid_rowconfigure(0, weight=1)
        self.main_frame.grid_columnconfigure(0, weight=1)

        self.init_home_frame()
        self.init_explorer_frame()
        self.init_quiz_frame()

        self.show_home_frame()

    def hide_all_frames(self):
        self.home_frame.grid_forget()
        self.explorer_frame.grid_forget()
        self.quiz_frame.grid_forget()
        
        self.home_btn.configure(fg_color="transparent", text_color=LIGHT_TEXT)
        self.explorer_btn.configure(fg_color="transparent", text_color=LIGHT_TEXT)
        self.quiz_btn.configure(fg_color="transparent", text_color=LIGHT_TEXT)

    def show_home_frame(self):
        self.hide_all_frames()
        self.home_frame.grid(row=0, column=0, sticky="nsew")
        self.home_btn.configure(fg_color=GOLD, text_color=DARK_BG)

    def show_explorer_frame(self):
        self.hide_all_frames()
        self.explorer_frame.grid(row=0, column=0, sticky="nsew")
        self.explorer_btn.configure(fg_color=GOLD, text_color=DARK_BG)

    def show_quiz_frame(self):
        self.hide_all_frames()
        self.quiz_frame.grid(row=0, column=0, sticky="nsew")
        self.quiz_btn.configure(fg_color=GOLD, text_color=DARK_BG)

    def init_home_frame(self):
        self.home_frame = ctk.CTkFrame(self.main_frame, fg_color="transparent")
        self.home_frame.grid_columnconfigure(0, weight=1)

        title = ctk.CTkLabel(self.home_frame, text="Welcome to Egypt in a Box", font=ctk.CTkFont(size=36, weight="bold"), text_color=GOLD)
        title.grid(row=0, column=0, pady=(50, 20))

        subtitle = ctk.CTkLabel(self.home_frame, text="A Phygital Experience Combining Physical Touch with Digital Learning.", font=ctk.CTkFont(size=18), text_color=LIGHT_TEXT, justify="center")
        subtitle.grid(row=1, column=0, pady=(0, 40))

        instructions = ctk.CTkLabel(self.home_frame, text="Explore the secrets of Ancient Egypt using the sidebar navigation.\n1. Go to Box Explorer to learn.\n2. Go to History Quiz to test your knowledge.", font=ctk.CTkFont(size=16), text_color="#aaaaaa", justify="center")
        instructions.grid(row=2, column=0, pady=(0, 40))
        
        start_btn = ctk.CTkButton(self.home_frame, text="Start Exploring", fg_color=GOLD, text_color=DARK_BG, hover_color=DARK_GOLD, font=ctk.CTkFont(size=16, weight="bold"), command=self.show_explorer_frame, height=50, width=250)
        start_btn.grid(row=3, column=0)

    def init_explorer_frame(self):
        self.explorer_frame = ctk.CTkFrame(self.main_frame, fg_color="transparent")
        self.explorer_frame.grid_rowconfigure(1, weight=1)
        self.explorer_frame.grid_columnconfigure(1, weight=1)

        header = ctk.CTkLabel(self.explorer_frame, text="Interactive Box Explorer", font=ctk.CTkFont(size=24, weight="bold"), text_color=GOLD)
        header.grid(row=0, column=0, columnspan=2, pady=(0, 20), sticky="w")

        self.boxes_frame = ctk.CTkFrame(self.explorer_frame, width=200, fg_color="#222222")
        self.boxes_frame.grid(row=1, column=0, sticky="nsew", padx=(0, 20))
        
        self.content_frame = ctk.CTkFrame(self.explorer_frame, fg_color="#222222")
        self.content_frame.grid(row=1, column=1, sticky="nsew")
        self.content_frame.grid_rowconfigure(1, weight=1)
        self.content_frame.grid_columnconfigure(0, weight=1)

        self.content_title = ctk.CTkLabel(self.content_frame, text="Select a Box", font=ctk.CTkFont(size=20, weight="bold"), text_color=GOLD)
        self.content_title.grid(row=0, column=0, pady=20, padx=20, sticky="w")

        self.content_text = ctk.CTkTextbox(self.content_frame, fg_color="transparent", text_color=LIGHT_TEXT, font=ctk.CTkFont(size=16), wrap="word")
        self.content_text.grid(row=1, column=0, pady=10, padx=20, sticky="nsew")
        self.content_text.insert("0.0", "Click on one of the boxes on the left to uncover its secrets!")
        self.content_text.configure(state="disabled")

        boxes = [
            ("Mummification Secrets", self.load_mummification),
            ("Pyramid Engineering", self.load_pyramids),
            ("Hieroglyphic Writing", self.load_hieroglyphs)
        ]

        for i, (en_title, command) in enumerate(boxes):
            btn = ctk.CTkButton(self.boxes_frame, text=en_title, command=command, fg_color="#333333", text_color=GOLD, hover_color="#444444", height=80, font=ctk.CTkFont(size=14, weight="bold"))
            btn.grid(row=i, column=0, padx=10, pady=10, sticky="ew")

    def update_explorer_content(self, title, content):
        self.content_title.configure(text=title)
        self.content_text.configure(state="normal")
        self.content_text.delete("0.0", "end")
        self.content_text.insert("0.0", content)
        self.content_text.configure(state="disabled")

    def load_mummification(self):
        content = (
            "Mummification was a sacred process designed to preserve the body for the afterlife.\n\n"
            "Step 1: Purification of the body.\n"
            "Step 2: Removal of internal organs (stored in Canopic jars).\n"
            "Step 3: Drying the body with Natron salt for 40 days.\n"
            "Step 4: Wrapping the body in linen cloth.\n\n"
            "Fun Fact: The heart was left inside because it was believed to be the center of intelligence and feeling!"
        )
        self.update_explorer_content("Mummification Secrets", content)

    def load_pyramids(self):
        content = (
            "The Pyramids of Giza are engineering marvels built as tombs for the Pharaohs.\n\n"
            "- The Great Pyramid was built for Pharaoh Khufu.\n"
            "- It was the tallest man-made structure in the world for over 3,800 years!\n"
            "- Workers used ramps and wooden sledges to move massive limestone blocks.\n\n"
            "Imagine moving blocks that weigh 2.5 tons each without modern machinery!"
        )
        self.update_explorer_content("Pyramid Engineering", content)

    def load_hieroglyphs(self):
        content = (
            "Hieroglyphics were the formal writing system used in Ancient Egypt.\n\n"
            "- It consists of hundreds of symbols representing sounds, words, or ideas.\n"
            "- The Rosetta Stone, discovered in 1799, helped scholars decode the language.\n"
            "- Papyrus, made from reeds, was used as paper.\n\n"
            "Can you write your name like an ancient Egyptian?"
        )
        self.update_explorer_content("Hieroglyphic Writing", content)

    def init_quiz_frame(self):
        self.quiz_frame = ctk.CTkFrame(self.main_frame, fg_color="transparent")
        self.quiz_frame.grid_rowconfigure(2, weight=1)
        self.quiz_frame.grid_columnconfigure(0, weight=1)

        self.questions = [
            {
                "q": "Which organ was NOT removed during mummification?",
                "options": ["Brain", "Lungs", "Heart", "Liver"],
                "answer": "Heart"
            },
            {
                "q": "For which Pharaoh was the Great Pyramid built?",
                "options": ["Ramses II", "Khufu", "Tutankhamun", "Cleopatra"],
                "answer": "Khufu"
            },
            {
                "q": "What artifact helped decode Hieroglyphics?",
                "options": ["The Sphinx", "Rosetta Stone", "Valley of Kings", "Canopic Jars"],
                "answer": "Rosetta Stone"
            }
        ]
        self.current_q_index = 0
        self.score = 0

        self.quiz_header = ctk.CTkLabel(self.quiz_frame, text="History Quiz", font=ctk.CTkFont(size=24, weight="bold"), text_color=GOLD)
        self.quiz_header.grid(row=0, column=0, pady=(0, 20), sticky="w")

        self.quiz_container = ctk.CTkFrame(self.quiz_frame, fg_color="#222222")
        self.quiz_container.grid(row=1, column=0, sticky="nsew", padx=20, pady=20)
        self.quiz_container.grid_columnconfigure(0, weight=1)

        self.question_lbl = ctk.CTkLabel(self.quiz_container, text="", font=ctk.CTkFont(size=18, weight="bold"), text_color=LIGHT_TEXT, justify="center")
        self.question_lbl.grid(row=0, column=0, pady=30, padx=20)

        self.option_buttons = []
        for i in range(4):
            btn = ctk.CTkButton(self.quiz_container, text="", fg_color="#333333", hover_color="#555555", text_color=GOLD, font=ctk.CTkFont(size=16), height=40, command=lambda idx=i: self.check_answer(idx))
            btn.grid(row=i+1, column=0, pady=10, padx=50, sticky="ew")
            self.option_buttons.append(btn)

        self.feedback_lbl = ctk.CTkLabel(self.quiz_container, text="", font=ctk.CTkFont(size=18, weight="bold"))
        self.feedback_lbl.grid(row=5, column=0, pady=20)

        self.next_btn = ctk.CTkButton(self.quiz_container, text="Next Question", fg_color=GOLD, text_color=DARK_BG, hover_color=DARK_GOLD, command=self.next_question, state="disabled")
        self.next_btn.grid(row=6, column=0, pady=20)

        self.load_question()

    def load_question(self):
        if self.current_q_index < len(self.questions):
            q_data = self.questions[self.current_q_index]
            self.question_lbl.configure(text=q_data["q"])
            self.feedback_lbl.configure(text="")
            self.next_btn.configure(state="disabled")
            
            for i, option in enumerate(q_data["options"]):
                self.option_buttons[i].configure(text=option, state="normal", fg_color="#333333")
        else:
            self.show_results()

    def check_answer(self, selected_idx):
        q_data = self.questions[self.current_q_index]
        selected_option = q_data["options"][selected_idx]
        
        for btn in self.option_buttons:
            btn.configure(state="disabled")
            
        if selected_option == q_data["answer"]:
            self.score += 1
            self.option_buttons[selected_idx].configure(fg_color="green")
            self.feedback_lbl.configure(text="Correct!", text_color="green")
        else:
            self.option_buttons[selected_idx].configure(fg_color="red")
            for i, opt in enumerate(q_data["options"]):
                if opt == q_data["answer"]:
                    self.option_buttons[i].configure(fg_color="green")
            self.feedback_lbl.configure(text="Incorrect!", text_color="red")

        self.next_btn.configure(state="normal")

    def next_question(self):
        self.current_q_index += 1
        self.load_question()

    def show_results(self):
        self.question_lbl.configure(text=f"Quiz Completed!\n\nYour Score: {self.score} out of {len(self.questions)}")
        for btn in self.option_buttons:
            btn.grid_forget()
        self.feedback_lbl.grid_forget()
        self.next_btn.configure(text="Restart Quiz", command=self.restart_quiz, state="normal")

    def restart_quiz(self):
        self.current_q_index = 0
        self.score = 0
        self.next_btn.configure(text="Next Question", command=self.next_question)
        for i, btn in enumerate(self.option_buttons):
            btn.grid(row=i+1, column=0, pady=10, padx=50, sticky="ew")
        self.feedback_lbl.grid(row=5, column=0, pady=20)
        self.load_question()

if __name__ == "__main__":
    app = EgyptInABoxApp()
    app.mainloop()
